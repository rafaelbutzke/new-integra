package br.com.bbveiculos.newintegra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewIntegraApplicationTests {

	@Test
	void contextLoads() {
	}

}
